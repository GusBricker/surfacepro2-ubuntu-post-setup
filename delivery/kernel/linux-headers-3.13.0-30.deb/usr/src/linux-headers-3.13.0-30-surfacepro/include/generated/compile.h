/* This file is auto generated, version 54 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#54 SMP Sat Jun 28 14:36:19 PDT 2014"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "luna-surface"
#define LINUX_COMPILER "gcc version 4.8.2 (Ubuntu 4.8.2-19ubuntu1) "
